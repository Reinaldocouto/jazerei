This directory will hold Elgg's ``settings.php`` file after installation.

If the web server cannot write to this directory, you will have to manually copy Elgg's ``settings.example.php`` here
and apply your changes. E.g.

.. code:: bash

    # at project root
    cp vendor/elgg/elgg/elgg-config/settings.example.php elgg-config/settings.php
