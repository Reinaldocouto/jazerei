<?php
/**
 * Blog view sidebar
 */
