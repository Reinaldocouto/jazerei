<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'custom_index:settings:about' => "Over",
	'custom_index:settings:enable_module' => "Schakel de '%s' module in",
);
