<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'custom_index:settings:about' => "Despre",
	'custom_index:settings:enable_module' => "Activează modulul '%s'",
);
