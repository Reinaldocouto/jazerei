<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:river_widget:name' => "Activity",
	'widgets:river_widget:description' => "Display latest activity",
	'widgets:river_widget:type' => "Type of activity",
	'widgets:river_widget:friends' => 'Friends activity',
	'widgets:river_widget:all' => 'All site activity',

	'widgets:group_activity:name' => 'Group activity',
	'widgets:group_activity:description' => 'View the activity in one of your groups',
	'widgets:group_activity:edit:select' => 'Select a group',
	'widgets:group_activity:content:noactivity' => 'There is no activity in this group',
	'widgets:group_activity:content:noselect' => 'Edit this widget to select a group',
	
	'collection:river' => "Activity",
	'collection:river:group' => "Group activity",
	'groups:tool:activity' => 'Enable group activity',
	'groups:tool:activity:description' => 'Show an activity feed about group related content.',
	
);
