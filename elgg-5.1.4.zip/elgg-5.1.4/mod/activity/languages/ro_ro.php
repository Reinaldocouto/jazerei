<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:river_widget:name' => "Activitate",
	'widgets:river_widget:description' => "Afișează ultimele activități",
	'widgets:river_widget:type' => "Tipul activității",
	'widgets:river_widget:friends' => 'Activitatea prietenilor',
	'widgets:river_widget:all' => 'Toată activitatea site-ului',

	'widgets:group_activity:name' => 'Activitatea de grup',
	'widgets:group_activity:description' => 'Vezi activitatea unui grup de-al tău',
	'widgets:group_activity:edit:select' => 'Selectează un grup',
	'widgets:group_activity:content:noactivity' => 'Nu există activitate în acest grup',
	'widgets:group_activity:content:noselect' => 'Editează acest modul pentru a selecta un grup',
	
	'collection:river' => "Activitate",
	'collection:river:group' => "Activitatea grupului",
	'groups:tool:activity' => 'Activează activitatea grupului',
	
);
